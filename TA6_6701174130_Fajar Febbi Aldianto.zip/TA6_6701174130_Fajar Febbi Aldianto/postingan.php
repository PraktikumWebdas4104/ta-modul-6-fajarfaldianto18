<center>
<table>
	<tr>
		<th width="100"><a href = "menu.php">HOME</HEAD></a></th>
		<th width="100"><a href="edprofile.php">EDIT PROFILE</a></th>
		<th width="100"><a href="post.php">POSTING</a></th>
		<th width="100"><a href="dafpostingan.php">LIAT POSTINGAN</a></th>
		<th width="100"><a href="semuaposting.php">LIAT SEMUA POSTINGAN</a></th>
		<th width="100"><a href="logout.php">KELUAR</a></th>
	</tr>
</table></center><br><br><br><br>
<table border="3">
	<tr>
		<th>nim</th> <th>nama</th> <th>foto</th> <th>postingan</th>
	</tr>
<?php 
		session_start();
		$host="localhost";
		$user="root";
		$pass="";
		$db="mahasiswa";
		$conn=mysqli_connect($host,$user,$pass,$db);

		$sql=$conn->query("SELECT `nim`,`nama`,`foto`,`cerita` FROM `posting`");
		$no=1;
		while($row=mysqli_fetch_array($sql)){
			echo"<tr>
					<td>$row[0]</td> <td>$row[1]</td> <td>$row[2]</td> <td>$row[3]</td>
				</tr>";
				$no++;			
		}
 ?>
</table>