<center>
	<h1>Form Registrasi</h1>
<form method="POST">
	<table>
		<tr>
			<td>Nama</td>
			<td>:</td>
			<td><input type="text" name="nama" placeholder=""></td>
		</tr>
		<tr>
			<td>Nim</td>
			<td>:</td>
			<td><input type="text" name="nim" placeholder=""></td>
		</tr>
		<tr>
			<td>Kelas</td>
			<td>:</td>
			<td><input type="radio" name="kelas" value="MI4101">MI4101 &nbsp;
				<input type="radio" name="kelas" value="MI4102">MI4102 &nbsp;
				<input type="radio" name="kelas" value="MI4103">MI4103 &nbsp;
				<input type="radio" name="kelas" value="MI4104">MI4104</td>
		</tr>
		<tr>
			<td>Jenis Kelamin</td>
			<td>:</td>
			<td><input type="radio" name="jnkl" value="Laki-laki">Laki-Laki &nbsp;
				<input type="radio" name="jnkl" value="Perempuan">Perempuan</td>
		</tr>
		<tr>
			<td>Hobi</td>
			<td>:</td>
			<td>
				<input type="checkbox" name="hobi" value="Berantem">Berantem
				<input type="checkbox" name="hobi" value="Futsal">Futsal
				<input type="checkbox" name="hobi" value="Toring">Toring
				<input type="checkbox" name="hobi" value="Lari">Lari
				<input type="checkbox" name="hobi" value="Balap">Balap<br></td>
		</tr>
		<tr>
			<td>Fakultas</td>
			<td>:</td>
			<td><select name="fakultas">
				<option value="pil">Pilih</option>
				<option value="FIT">Fakultas Ilmu Terapan</option>
				<option value="FIK">Fakultas Industri Kreatif</option>
				<option value="FEB">Fakultas Ekonomi Bisnis</option>
			</select></td>
		</tr>
	
		<tr>
			<td>Alamat</td>
			<td>:</td>
			<td><textarea name="alamat"></textarea></td>
		</tr>
		<tr>
			<td>Password</td>
			<td>:</td>
			<td><input type="Password" name="pass"></td>
		</tr>
		<tr>
			<td></td>
			<td></td>
			<td align="right">
				<button><a href="login.php">Login</a></button>
				<input></td>
		</tr>
	</table><br>
	
</form>


<?php
	if (isset($_POST['submit'])) {
		include"prosesregris.php";
	}
?>