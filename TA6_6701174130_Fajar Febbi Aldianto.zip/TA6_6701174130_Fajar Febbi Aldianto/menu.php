<br><br><center>
<table>
	<tr>
		<th width="100"><a href = "menu.php">HOME</HEAD></a></th>
		<th width="100"><a href="edprofile.php">EDIT PROFILE</a></th>
		<th width="100"><a href="post.php">POSTING</a></th>
		<th width="100"><a href="dafpostingan.php">LIAT POSTINGAN</a></th>
		<th width="100"><a href="semuaposting.php">LIAT SEMUA POSTINGAN</a></th>
		<th width="100"><a href="logout.php">KELUAR</a></th>
	</tr>
</table></center><br><br>
<?php 
	session_start();
	echo "<center>"; "pp"." ".$_SESSION['nama']."<br>";
	"data diri :"."<br>";
	"Nama 			:"." ".$_SESSION['nama']."<br>";
	"Nim 			:"." ".$_SESSION['nim']."<br>";
	"Password 		:"." ".$_SESSION['password']."<br>";
	"Kelas 		:"." ".$_SESSION['kelas']."<br>";
	"Jenis Kelamin :"." ".$_SESSION['jeniskelamin']."<br>";
	"Hobi 			:"." ".$_SESSION['hobi']."<br>";
	"Fakultas 		:"." ".$_SESSION['fakultas']."<br>";
	"Alamat 		:"." ".$_SESSION['alamat']."<br>";
	"</center>";
 ?>